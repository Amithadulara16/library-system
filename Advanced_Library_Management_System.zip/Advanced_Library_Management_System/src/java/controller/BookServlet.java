package controller;

import dao.BookDAO;
import model.Book; // <-- correct import
import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/book")
public class BookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String author = request.getParameter("author");

        if (title == null || title.trim().isEmpty() || author == null || author.trim().isEmpty()) {
            request.setAttribute("error", "Invalid input!");
            request.getRequestDispatcher("addBook.jsp").forward(request, response);
            return;
        }

        Book book = new Book(title, author); // <-- corrected line
        new BookDAO().addBook(book);

        response.sendRedirect("dashboard.jsp");
    }
}
