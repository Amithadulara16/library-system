package controller.filter;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;

@WebFilter("/addBook.jsp")
public class AuthFilter implements Filter {
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpSession session = ((HttpServletRequest) request).getSession(false);
        if (session == null || !"Admin".equals(session.getAttribute("role"))) {
            ((HttpServletResponse) response).sendRedirect("error.jsp");
        } else {
            chain.doFilter(request, response);
        }
    }
}
